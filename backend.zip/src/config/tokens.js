const tokenTypes = {
  ACCESS: 'access',
  REFRESH: 'refresh',
};

module.exports = {
  tokenTypes,
};
